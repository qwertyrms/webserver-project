from flask import render_template
from app import app
from app.forms import LoginForm

@app.route('/')
@app.route('/home')
def home():
    user = {'username': 'Remon'}
    messages = [
        {
            'author': {'username': 'John'},
            'body': 'Have a great day!'
        },
        {
            'author': {'username': 'Jane'},
            'body': 'See you Thursday!'
        }
    ]
    return render_template('home.html', title = 'CUNY', user = user, messages = messages)

@app.route('/login')
def login():
    form = LoginForm()
    return render_template('login.html', title = 'Sign In', form = form)